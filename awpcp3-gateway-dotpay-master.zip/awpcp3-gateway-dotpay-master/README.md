AWPCP 3.0+ Dotpay Gateway
=====================

*English version below*

####Wtyczka dla WordPress/AWPCP 3.0+ dodająca bramkę płatności Dotpay####

### Instrukcja: ###
1. Pobierz wtyczkę (https://github.com/rokettoeu/awpcp3-gateway-dotpay/archive/master.zip)
2. Umieść folder z wtyczką w wp-content/plugins
3. Aktywuj wtyczkę w Kokpicie
4. Przjedź do zakładki Payment w Classifieds Settings, wtedy aktywuj i skonfiguruj bramkę Dotpay

---------------------------------------

####WordPress/AWPCP 3.0+ plugin adding form based Dotpay payment gateway####

### Instructions: ###
1. Download the plugin (https://github.com/rokettoeu/awpcp3-gateway-dotpay/archive/master.zip)
2. Put plugin folder inside wp-content/plugins
3. Activate plugin in Dashboard
4. Go to Payment tab in Classifieds Settings, then enable and configure Dotpay gateway